package com.rajchowdhary.app

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val container = FrameLayout(this)
        webView = WebView(this)
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)

        container.addView(webView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        container.addView(progress, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 8
        ))
        setContentView(container)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val script = """
                    (function() {
                      if (document.getElementById('raj-rgb-style')) return;
                      var style = document.createElement('style');
                      style.id = 'raj-rgb-style';
                      style.textContent = `
                        body {
                          background-image:
                            radial-gradient(circle at 8% 12%, rgba(0,255,190,.14), transparent 32%),
                            radial-gradient(circle at 92% 25%, rgba(180,0,255,.16), transparent 34%),
                            radial-gradient(circle at 50% 100%, rgba(0,130,255,.13), transparent 38%) !important;
                          background-attachment: fixed !important;
                        }
                        a, button, [role="button"], input[type="button"], input[type="submit"] {
                          transition: box-shadow .3s ease, filter .3s ease;
                          box-shadow: 0 0 7px rgba(0,255,220,.30),
                                      0 0 14px rgba(170,0,255,.22) !important;
                        }
                        h1, h2, h3 {
                          text-shadow: 0 0 8px rgba(0,255,220,.32),
                                       0 0 14px rgba(190,0,255,.20);
                        }
                        @media (prefers-reduced-motion: no-preference) {
                          a, button, [role="button"] {
                            animation: rajRgbGlow 5s ease-in-out infinite alternate;
                          }
                          @keyframes rajRgbGlow {
                            0% { box-shadow: 0 0 6px rgba(0,255,220,.24), 0 0 12px rgba(0,100,255,.18) !important; }
                            50% { box-shadow: 0 0 9px rgba(255,0,170,.30), 0 0 18px rgba(150,0,255,.24) !important; }
                            100% { box-shadow: 0 0 8px rgba(255,180,0,.24), 0 0 16px rgba(0,255,150,.22) !important; }
                          }
                        }
                      `;
                      document.head.appendChild(style);
                    })();
                """.trimIndent()
                view?.evaluateJavascript(script, null)
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("https://deft-sorbet-dde6d5.netlify.app/")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
