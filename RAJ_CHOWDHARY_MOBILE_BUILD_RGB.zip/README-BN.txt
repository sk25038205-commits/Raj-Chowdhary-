RAJ CHOWDHARY Android App Starter

এই প্রজেক্টটি Android Studio-তে খোলার জন্য তৈরি করা হয়েছে।
এটি একটি WebView অ্যাপ: ইন্টারনেট সংযোগ থাকলে তোমার দেওয়া ওয়েবসাইট অ্যাপের ভেতরে দেখাবে।

APK বানাতে:
1. কম্পিউটারে Android Studio ইনস্টল করে এই ZIP Extract করো।
2. Android Studio থেকে Open করে এই ফোল্ডারটি নির্বাচন করো।
3. Gradle Sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপো।
4. তৈরি APK app/build/outputs/apk/debug/app-debug.apk-এ থাকবে।

নোট: এই ZIP-এ Android Studio প্রজেক্টের সোর্স আছে, তৈরি APK নয়।
ওয়েবসাইটটি এই পরিবেশ থেকে যাচাই করা যায়নি; অ্যাপ চালিয়ে সাইটটি খুলছে কি না পরীক্ষা করতে হবে।
